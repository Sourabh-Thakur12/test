#include <iostream>
#include <ctime>
using namespace std;

class InsertionSort{
    int  *arr;
    int size,c;
    public:
       void ISort();
       void setValues();
       void disp();

    InsertionSort(int x){
        c=0; 
        size =x;
        arr= new int[size];
   }    

   ~InsertionSort(){
    delete[] arr;
   }
};
void InsertionSort:: setValues(){
        srand(time(0));
    for(int i =0; i<size; i++){
        arr[i]=rand()%100+1;
    }
    cout<<"The array is: "<<endl;
    
}
void InsertionSort:: disp(){
    for(int i=0; i<size; i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}
void InsertionSort:: ISort(){
    int j=0;
    int key;
    for(int i=1;i<size;i++){
        j=i-1;
        int c=0;
        key=arr[i];
        cout<<"pass"<<i<<endl;
        while(j>=0 && key<arr[j]){
            arr[j+1]=arr[j];
            j= j-1;
            c++;
        }
        arr[j+1]=key;
        disp();
        cout<<"Comparisons: "<<c<<endl;
    }
}


int main(){
    int n;
    cout<<"Enter number of values: ";
    cin>>n;
    InsertionSort obj(n);
    obj.setValues();
    obj.ISort();
}
