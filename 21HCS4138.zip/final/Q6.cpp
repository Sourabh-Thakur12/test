#include<iostream>
using namespace std;

void m(int n,char f, char t, char v){
    char A=f,B=v,C=t;
    if(n>0){
        m(n-1,A,B,C);
        cout<<"Move "<<n<<" from "<<A<<" to "<<C<<endl;
        m(n-1,B,C,A);
    }
}

int main(){
    cout<<"Enter the number of disk ";
    int n ;
    cin>>n;
    char f = 'A',v='B',t='C';
    m(n,f,t,v);
}