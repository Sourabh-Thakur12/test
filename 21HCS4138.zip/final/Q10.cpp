#include<iostream>
using namespace std;

string str;

void permute(int l, int r) 
{ 
    if (l == r) 
        cout<<str<<endl; 
    else
    { 
        for (int i = l; i <= r; i++) 
        { 
            swap(str[l], str[i]); 
   
            permute(l+1, r); 

           swap(str[l], str[i]); 
        } 
    } 
} 

void permute_rep(int l, int r){
    if(l==r)
        cout<< str<<endl;
    else
    {
        for(int i =l; i<=r;i++){
        if(l!=i || str[l] != str[i]){
            swap(str[l],str[i]);
            permute_rep(l+1,r);
            swap(str[l],str[i]);}
        }
    }
        
}
   
int main() 
{ 
    cout<<"Enter the string ";
    cin>>str; 
    int n = str.size(); 
    int choice;
    cout<<"1. for non-Repeting permutations, 2. for Repeting permutattions "<<endl;
    cin>>choice;
    switch(choice){
    case 1:
        permute(0,n-1);
        break;
    case 2:
        permute_rep(n-1,0);
        break;
   }
    return 0; 
} 
