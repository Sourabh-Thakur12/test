#include<iostream>
using namespace std;

class lg {
    public:
    int *arr1;
    int *arr2;
    int *arr_con;
    int *arr_dis;
    int *arr_nand;
    int *arr_nor;
    int *arr_xorr;
    int *arr_xnor;
    int *arr_neg1;
    int *arr_neg2;
    int *arr_conditional;
    int *arr_BiCondiotional;
    int n; 
    void get_input();
    void display();
    void conjuction();
    void disjunction();
    void nand();
    void nor();
    void xorr();
    void xnor();
    void negation();
    void conditional();
    void bi_conditional();

    

    lg(int x){
        n=x;
        arr1 = new int[n];
        arr2 = new int[n];
        arr_con =new int[n];
        arr_dis =new int[n];
        arr_nand =new int[n];
        arr_nor =new int[n];
        arr_xorr =new int[n];
        arr_xnor =new int[n];
        arr_neg1 =new int[n];
        arr_neg2 =new int[n];
        arr_conditional =new int[n];
        arr_BiCondiotional =new int[n];
    
    }
    ~lg(){
        delete []arr1;
        delete []arr2;
        delete []arr_con;
        delete []arr_dis;
        delete []arr_nand;
        delete []arr_nor;
        delete []arr_xorr;
        delete []arr_xnor;
        delete []arr_neg1;
        delete []arr_neg2;
        delete []arr_conditional;
        delete []arr_BiCondiotional;
    }


};

void lg :: get_input(){
    cout<<"Enter truth values of x and y in pairs ";
    for(int i =0; i<n;i++){
        cin>>arr1[i]>>arr2[i];
    }
}

void lg:: display(){
    cout<<"The elements after performing operation:-"<<endl;
    cout<<"X\tY\tAnd\tOr\tNand\tnor\tXor\tXnor\tnot1\tnot2\tCond\tBi-C\n";
    for(int i =0; i<n; i++){
        cout<<arr1[i]<<"\t"<<arr2[i]<<"\t"<<arr_con[i]<<"\t"<<arr_dis[i]<<"\t"<<arr_nand[i]<<"\t"<<arr_nor[i]<<"\t"<<arr_xorr[i]<<"\t"<<arr_xnor[i]<<"\t"<<arr_neg1[i]<<"\t"<<arr2[i]<<"\t"<<arr_conditional[i]<<"\t"<<arr_BiCondiotional[i]<<"\n";
    }
}

void lg::conjuction(){
    for(int i=0; i<n;i++){
        arr_con[i]=arr1[i] & arr2[i];
    }
}

void lg::disjunction(){
    for(int i=0; i<n;i++){
        arr_dis[i]=arr1[i] | arr2[i];
    }
}

void lg::nand(){
    for(int i=0; i<n;i++){
        arr_nand[i]=!(arr1[i] & arr2[i]);
    }
}

void lg::nor(){
    for(int i=0; i<n;i++){
        arr_nor[i]=!(arr1[i] | arr2[i]);
    }
}

void lg::xorr(){
    for(int i=0; i<n;i++){
        arr_xorr[i]=arr1[i] ^ arr2[i];
    }
}

void lg::xnor(){
    for(int i=0; i<n;i++){
        arr_xnor[i]=!(arr1[i] ^ arr2[i]);
    }
}

void lg::conditional(){
    for(int i=0; i<n;i++){
        arr_conditional[i]=(~arr1[i] | arr2[i]);
    }
}

void lg::bi_conditional(){
    for(int i=0; i<n;i++){
        arr_BiCondiotional[i]=((!arr1[i] | arr2[i])&(!arr2[i]|arr1[i]));
    }
}

void lg::negation(){
    for(int i=0; i<n;i++){
        arr_neg1[i]=!(arr1[i]);
        arr_neg2[i]=!(arr2[i]);
    }
}



int main(){
    int n;
    cout<<"Enter the number of values ";
    cin>>n;
    lg ob(n);
    ob.get_input();
    ob.conjuction();
    ob.disjunction();
    ob.nand();
    ob.nor();
    ob.xorr();
    ob.xnor();
    ob.negation();
    ob.conditional();
    ob.bi_conditional();
    ob.display();

}