#include<iostream>
using namespace std;
int main(){
    int m,i,l;
    cout<<"enter the value of m: ";
    cin>>m;
    cout<<"The given tree is FULL "<<m<<"-ARY Tree\n";
    cout<<"How many internal vertices does tree have ?";
    cin>>i;
    l=(m-1)*i+1;
    cout<<"The given tree has "<<l<<" leaf nodes.";
    return 0;
}