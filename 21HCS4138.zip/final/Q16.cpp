#include<iostream>
using namespace std;
class complete{
    int m;
    int**array=new int*[m];
    public:
    complete(){
    // for(int i=0;i<m;i++){
    //     array[i]=new int[m];
    // }}
    }
    void inp(){
        cout<<"enter the number of vertices of graph ";
        cin>>m;
        for(int i=0;i<m;i++){
        array[i]=new int[m];
    }
    }
    void matrix(){
        cout<<"enter the matrix:\n";
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                cin>>array[i][j];
            }
            
        }
        cout<<endl;
        cout<<"Entereed matrix is:\n";
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                cout<<array[i][j]<<" ";
            }cout<<endl;
            
        }
        cout<<endl;
        
    }
    void check_complete(){
        bool p=1;
        for (int  i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (i!=j)
                {
                    if(array[i][j]!=1){
                        p=0;
                        break;
                    }
                }
                else{
                    if (array[i][j]!=0)
                    {
                        p=0;
                        break;
                    }
                    
                }
                
            }
            
        }
        if (p)
        {
            cout<<"Given graph is Complete graph ";
        }
        else
        cout<<"Given graph is not complete graph";

        
        
    }

};
int main(){
    complete c;
    c.inp();
    c.matrix();
    c.check_complete();
    return 0;
}