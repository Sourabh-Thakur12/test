#include<iostream>
#include<cmath>
using namespace std;

class Polynomial{
    int x,deg;
    int*arr;
    public:
        void getValues();
        void disp();
        void values();
    Polynomial(int x){
        deg= x;
        arr = new int[deg+1];
    }
    ~Polynomial(){
        delete[]arr;
    }    

};
void Polynomial::getValues(){
    for(int i=0;i<=deg;i++){
    cout<<"Enter the coefficient of x^"<<i<<": ";
    cin>>arr[i];}
}

void Polynomial::disp(){
    cout<<"The Polynomial is:";
    for(int i=0; i<=deg; i++){
        cout<<arr[deg-i]<<"x^"<<deg-i;
        if(i<deg){
            cout<<"+ ";
        }
    }
} 

void Polynomial::values(){
    int sum;
    cout<<"\nEnter the value of x:";
    cin>>x;
    for(int i=0;i<=deg;i++){
        sum+=arr[i]*(pow(x,i));
    }
    cout<<sum;
}  
int main(){
    int deg;
    cout<<"Enter the degree of polynomial ";
    cin>>deg;
    Polynomial obj(deg);
    obj.getValues();
    obj.disp();
    obj.values();
    


}