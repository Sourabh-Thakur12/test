#include<iostream>
using namespace std;

void sum(int*arr,int n ,int c, int s){
    if(s==n-1){
        arr[s]=c;
        for(int i =0; i<n; i++){
        cout<<arr[i];
        if(i<n-1)
        cout<<"+";
        }
        cout<<endl;
        return;
    }
    for(int i=0; i<=c; i++){
        arr[s]=i;
        sum(arr,n,c-i,s+1);
    }
}


int main(){
    int n, c , s;
    cout<<"Enter the number of elements ";
    cin>>n;
    cout<<"Enter the sum of elements ";
    cin>>c;
    int *arr = new int [n];
    sum(arr,n,c,0);
    return 0;

}
