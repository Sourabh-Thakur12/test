#include<bits/stdc++.h>

using namespace std;

class Set{
	int size;
	int *arr;
		
	public:
		void getData(void);
		void removeDupli();
		void cardinality_PS(void);
		void powerset(void);
		void isMember(void);
		Set(int x){
	      size=x;
	      arr= new int[size];
	   }
};


void Set::getData(void){
	cout<<"Enter the elements of the set:";
	for(int i =0; i<size; i++){
		cin>>arr[i];
	}
	cout<<endl;
}

void Set::removeDupli(){
	int*temp =new int[size];
	int count =0;
	for (int i =0; i<size; i++){
		int x;
		x= arr[i];
		int found =0;
		
		for (int j=0; j<count;j++){
			if (temp[j]==x){
			found=1;
			break;}
		}
	if (found==0){
		temp[count++]=x;
	}
}
delete []arr;
int*arr=new int [count];
for(int i=0; i<count; i++){
	arr[i]=temp[i];
}
delete[] temp;
size = count;
cout<<"Array after removing duplicates:-";
 for (int i=0; i<size; i++){
 	cout<<arr[i]<<","; }
 	cout<<endl;
}


void Set::cardinality_PS(void){
	cout<<"The cardinality of power set is: "<<pow(2,size);
	cout<<endl;
}

void Set::powerset(void){
	
	for(int i=0; i<pow(2,size);i++){
		cout<<"{";
		for(int j=0; j<size;j++){
			if (i&(1<<j)) cout<<arr[j]<<",";
			}
		cout<<"}";	
	}
	cout<<endl;
}

void Set::isMember(void){
	int s, f=0;
	cout<<"Enter a element to check: ";
	cin>>s;
	for(int i =0; i<size; i++){
		if(arr[i]==s){
			cout<<s<<" is a element of set.\n";
			f = 1;
		}
	}
	if (f==0){
		cout<<s<<" is not a element of set.\n";
	}
	
}

int main(){
    int size;
    cout<<"Enter the cardinality of set:";
	cin>>size;
	Set s(size);
	s.getData();
	s.removeDupli();
	int choice;
	while(true){
	cout<<"Press 1 for Cardinality of power set.\nPress 2 for power set. \nPress 3 for checking member of set.\nPress 0 to exit:- ";
	cin>>choice;
    if (choice==1)
	   s.cardinality_PS();
	else if (choice==2)
	   s.powerset();
	else if (choice==3)
	   s.isMember();   
	else if (choice==0)
	   break;
	else 
	cout<<"Invalid Input\n";   
	
}
}
