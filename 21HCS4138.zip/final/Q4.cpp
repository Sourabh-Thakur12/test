#include <iostream>
#include "Q3.hpp"
using namespace std;
class Q4 : public Relation
{
};

int main(){
    int n;
    cout<<"Enter the cardinality of set :";
    cin>>n;
    Relation obj(n);
    
    obj.inputArr();
    obj.setSize();
    obj.display();
    obj.inputRel();
    obj.dispM();
    while (true)
    {
        int choice;
        cout<<"1.Equivalence,  2.Poset,  3.None,   4.to break"<<endl;
        cin>>choice;
        switch(choice){
            case 1:
            if (obj.checkRef() && obj.checkSymm() && obj.checkTrans())
                cout << "Relation is Equivalance" << endl;
            else
            {
                cout << "Relation is not Equivanance because ";
                if (!obj.checkRef())
                    cout << "it is not Reflexvive ";
                if (!obj.checkSymm())
                    cout << "it is not Symmetric ";
                if (!obj.checkTrans())
                    cout << "it is not Transitive ";
                cout << endl;
            }
            break;
        case 2:
            if (obj.checkRef() && obj.checkAntiSymm() && obj.checkTrans())
                cout << "Relation is Poset" << endl;
            else
            {
                cout << "Relation is not a Poset because ";
                if (!obj.checkRef())
                    cout << "it is not Reflexvive ";
                if (!obj.checkAntiSymm())
                    cout << "it is not Anti-Symmetric ";
                if (!obj.checkTrans())
                    cout << "it is not Transitive ";
                cout << endl;
            }
            break;
        case 3:
            if (!obj.checkRef() && !obj.checkTrans() && ((!obj.checkAntiSymm() || !obj.checkSymm())))
                cout << "Relation is None" << endl;
            else
            {
                cout << "Relation is not None because ";
                if (obj.checkRef() && obj.checkAntiSymm() && obj.checkTrans())
                    cout << "it is a Poset ";
                if (obj.checkRef() && obj.checkSymm() && obj.checkTrans())
                    cout << "it is an Equivalance relation ";
                cout << endl;
            }
            break;
         case 4:
         break;   
        default:
            cout << "Wrong Choice!" << endl;
        }
        if(choice==4) break;

            
    }
}
