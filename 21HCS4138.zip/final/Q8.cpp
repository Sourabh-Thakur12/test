#include <iostream>
#include <ctime>
using namespace std;

class BubbleSort{
    int  *arr;
    int size,Tcount,temp ;
    public:
       void bSort();
       void setValues();

    BubbleSort(int x){
        Tcount = 0;
        size =x;
        arr= new int[size];
   }    

   ~BubbleSort(){
    delete[] arr;
   }
};
void BubbleSort:: setValues(){
        srand(time(0));
    for(int i =0; i<size; i++){
        arr[i]=rand()%100+1;
    }
    cout<<"The array is: "<<endl;
    for(int i=0; i<size; i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

void BubbleSort:: bSort(){
    for(int i=0; i<size-1; i++){
        int count =0 ;
        for(int j=0; j<size-i-1; j++){
            if(arr[j]>arr[j+1])
            {
                count++ ;
                temp = arr[j];
                arr[j]= arr[j+1];
                arr[j+1]= temp;
            }
        }
        for (int j=0; j<size;j++){
            cout<<arr[j]<<" ";
        }
        Tcount+=count;
        cout<<"     No. of swaps = "<<count<<endl;
    }
    cout<<"Total no. of swaps = "<<Tcount<<endl;
}



int main(){
    int num;
    cout<<"Enter the length of array.";
    cin>>num;
    BubbleSort obj(num);
    obj.setValues();
     obj.bSort();

}