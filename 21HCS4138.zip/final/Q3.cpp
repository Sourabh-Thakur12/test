#include<iostream>
using namespace std;

class Relation
{
    int size;
    int ne;
    int a, b, aa, bb;
    int *arr;
    int **Rel;

public:
    void inputArr();
    void setSize();
    void inputRel();
    void display();
    void dispM();
    bool checkSymm();
    bool checkAntiSymm();
    bool checkRef();
    bool checkTrans();
    Relation(int x)
    {
        size = x;
        arr = new int[size];
        Rel = new int *[size];
        for (int i = 0; i < size; i++)
        {
            Rel[i] = new int[size];
        }
    }
    ~Relation()
    {
        for (int i = 0; i < size; i++)
        {
            delete Rel[i];
        }
        delete[] Rel;
        delete[] arr;
        // cout << "Destructor called";
    }
};
bool Relation::checkSymm(){
    bool y = true;
    for(int i =0; i<size;i++){
        for(int j=0; j<size; j++){
            if(Rel[i][j]!=Rel[j][i]){
                 y= false;
                 break;
            }
        }
    }
    return y;
}

bool Relation::checkAntiSymm(){
    bool y = true;
    for(int i =0; i<size;i++)
    {
        for(int j=0; j<size; j++)
        {
            if(Rel[i][j]==1 && Rel[j][i]==1)
            {
                if(i!=j){
                    y= false;
                    break;
                }
            }
        }
    }
    return y;
}

bool Relation::checkRef(){
    bool y = true;
    for(int i =0; i<size;i++){
            if(Rel[i][i] != 1){
                 y= false;
                 break;
            }
        }
    return y;
}

bool Relation::checkTrans(){
    bool y = true;
    for(int i =0; i<size;i++)
    {
        for(int j=0; j<size; j++)
        {
            for(int k=0; k<size; k++)
            {
                if(Rel[i][j]==1 && Rel[j][k]==1)
                { 
                    if (Rel[i][k] !=1)
                    {
                       y= false;
                       break;
                    }
                }       
            }if(!y)
            break;
        }if(!y)
        break;
    }
    return y;
}

void Relation::setSize()
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            Rel[i][j] = 0;
        }
    }
}
void Relation::inputArr()
{

    cout << "Enter the elements of the set" << endl;
    for (int i = 0; i < size; i++)
        cin >> arr[i];
    cout << endl;
}

void Relation::inputRel()
{
    cout << "Enter number of elements in the relation" << endl;
    cin >> ne;
    cout << "Enter the elements of the Relation" << endl;
    for (int k = 0; k < ne; k++)
    {
        cin >> a;
        cin >> b;
        for (int j = 0; j < size; j++)
        {
            if (a == arr[j])
                aa = j;
            if (b == arr[j])
                bb = j;
        }
        Rel[aa][bb] = 1;
    }
}
void Relation::display()
{
    cout << "{";
    for (int i = 0; i < size; i++)
    {
        cout << arr[i];
        if(i<size-1) cout<<",";
    }
    cout << "}";
    cout << endl;
}
void Relation::dispM()
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            cout << Rel[i][j] << " ";
        }
        cout << endl;
    }
}

int main()
{
    int s;
    cout << "Enter cardinality of set :";
    cin >> s;
    Relation obj(s);

    obj.inputArr();
    obj.setSize();
    obj.display();
    obj.inputRel();
    obj.dispM();
    while(true){
    int choice;
    cout<<"1.for Reflexivity,  2. for Symmetricity,  3.for AntiSymmetricity,   4. for Transitivity, 5. for exit "<<endl;
    cin>>choice;
    switch(choice){
    case 1:
        if(obj.checkRef())
            cout<<"Relation is Reflexive"<<endl;
        else cout<<"Relation is  not Reflexive"<<endl;   
        break; 
    case 2:
        if(obj.checkSymm())
            cout<<"Relation is Symmetric"<<endl;
        else cout<<"Relation is  not Symmetric"<<endl;   
        break; 
    case 3:
        if(obj.checkAntiSymm())
            cout<<"Relation is Anti-Symmetric"<<endl;
        else cout<<"Relation is  not Anti-Symmetric"<<endl;   
        break; 
    case 4:
        if(obj.checkRef())
            cout<<"Relation is Transitive"<<endl;
        else cout<<"Relation is  not Transitive"<<endl;   
        break;
    case 5:
        break;
    default:
        cout<<"Invalid Input"<<endl;  
        break;      
    }
    if(choice==5)
    break;
    }             
    return 0;
}
